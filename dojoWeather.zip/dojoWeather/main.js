function clickAlert(){
    alert("Loading weather report...")
}

function removeBox(){
    var delbox = document.getElementById("cookieBox")
    delbox.remove()
}
