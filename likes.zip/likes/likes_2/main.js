
click = 9
function clickCounter(){
    click++
    var countlike = document.querySelector("#countlike")
    countlike.innerText = `${click} like(s)`
}

click = 12
function nicholeCounter(){
    click++
    var nicholelike = document.querySelector("#nicholelike")
    nicholelike.innerText = `${click} like(s)`
}

click = 9
function jimCounter() {
    click++
    var jimlike = document.querySelector("#jimlike")
    jimlike.innerText = `${click} like(s)`
}