console.log("page loaded...");

function playVideo(element){
    element.play();
    element.mute();
}

function pauseVideo(element){
    element.pause(); 
}